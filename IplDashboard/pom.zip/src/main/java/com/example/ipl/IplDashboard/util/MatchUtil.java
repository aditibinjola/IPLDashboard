package com.example.ipl.IplDashboard.util;

import com.example.ipl.IplDashboard.model.Match;
import com.example.ipl.IplDashboard.repo.MatchRepository;
import com.opencsv.CSVReader;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Slf4j
@Service
public class MatchUtil {
    MatchRepository matchRepository;
    @Autowired
    public MatchUtil(MatchRepository matchRepository) {
        this.matchRepository = matchRepository;
        loadCSVDataIntoDB();
    }


    public List<String[]> readLineByLine(Path filePath) throws Exception {
        List<String[]> list = new ArrayList<>();

        try (Reader reader = Files.newBufferedReader(filePath)) {
            try (CSVReader csvReader = new CSVReader(reader)) {
                String[] line;
                while ((line = csvReader.readNext()) != null) {

                    Match match = new Match();
                    match.setID(Long.parseLong(line[0]));
                    match.setCity(line[1]);
                    match.setDate(LocalDate.parse(line[2]));
                    match.setSeason(Integer.parseInt(line[3]));
                    match.setMatchNumber(line[4]);
                    match.setTeam1(line[5]);
                    match.setTeam2(line[6]);
                    match.setVenue(line[7]);
                    match.setTossWinner(line[8]);
                    match.setTossDecision(line[9]);
                    match.setSuperOver(line[10]);
                    match.setWinningTeam(line[11]);
                    match.setWonBy(line[12]);
                    match.setMargin(Integer.parseInt(line[13]));
                    match.setMethod(line[14]);
                    match.setPlayer_of_Match(line[15]);
                    match.setTeam1Players(String.join(",", line[16]));
                    match.setTeam2Players(String.join(",", line[17]));
                    match.setUmpire1(line[18]);
                    match.setUmpire2(line[19]);

                    matchRepository.save(match);
                }
            }
        }
        return list;
    }


        public void loadCSVDataIntoDB() {
            try {
                readLineByLine(Path.of("IPLdata.csv"));

            } catch (Exception ex) {
                log.error("Error while reading csv file");
            }
        }


    }

